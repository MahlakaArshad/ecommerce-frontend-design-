// ✅ Modal popup
function showPopup(message) {
  document.getElementById("popupMessage").innerText = message;
  document.getElementById("popupModal").style.display = "flex";
}

function closePopup() {
  document.getElementById("popupModal").style.display = "none";
}

// ✅ Sidebar category click
function filterCategory(name) {
  showPopup("You selected category: " + name);
}

// ✅ Join/Login Buttons
function showLoginAlert(action) {
  showPopup(action + " button clicked!");
}

// ✅ Product Card Click
function showProductDetails(productName) {
  showPopup("Viewing details for: " + productName);
}

// ✅ Newsletter
function subscribeEmail(event) {
  event.preventDefault();
  const email = document.getElementById("emailInput").value;
  showPopup("Thanks for subscribing, " + email);
}

// ✅ Inquiry form
function sendInquiry(event) {
  event.preventDefault();
  showPopup("Your inquiry has been sent successfully!");
}

// ✅ Toggle dropdowns (All Categories, Language, Ship To)
function toggleDropdown(id) {
  const el = document.getElementById(id);
  if (el.style.display === "block") {
    el.style.display = "none";
  } else {
    // Close all others first
    document.querySelectorAll(".dropdown, .dropdown-list").forEach(d => d.style.display = "none");
    el.style.display = "block";
  }
}

// ✅ Close dropdowns when clicking outside
document.addEventListener("click", function (event) {
  const isDropdownToggle = event.target.closest(".dropdown-toggle, #category-menu, #lang-toggle, #ship-toggle");
  if (!isDropdownToggle) {
    document.querySelectorAll(".dropdown, .dropdown-list").forEach(drop => {
      drop.style.display = "none";
    });
  }
});

